<?php

namespace Database\Factories;

use App\Models\Course;
use Illuminate\Database\Eloquent\Factories\Factory;

class CourseFactory extends Factory
{
    protected $model = Course::class;

    public function definition(): array
    {
        return [
            'name' => $this->faker->sentence(3),
            'description' => $this->faker->paragraph,
            'grade' => rand(70, 100),
            'max_seats' => 20,
            'open_registration' => rand(0, 1) ? true : false,
            'cover_picture' => null,
            'course_complete' => false,
            'passing_grade' => rand(65, 100),
        ];
    }
}
