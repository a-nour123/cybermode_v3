<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\RoleResponsibility;
use App\Models\Subgroup;
use Illuminate\Database\Seeder;

class AddDashboardRoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Define the main permission groups with their corresponding subgroup names
        $permissionGroups = [
            'Aduit_Document_Policy' => 'Aduit Policy',
            'vulnerability_management' => 'Vulnerability Management',
            'Document_Policy' => 'Policy_Clauses',
        ];

        foreach ($permissionGroups as $groupKey => $subgroupName) {
            // Find the subgroup by name
            $subgroup = Subgroup::where('name', $subgroupName)->first();
            
            if (!$subgroup) {
                $this->command->error("Subgroup '{$subgroupName}' not found.");
                continue; // Skip to next group if subgroup not found
            }

            // Create dashboard permission for this group
            Permission::firstOrCreate([
                'key' => $groupKey . '.dashboard',
                'name' => 'Dashboard',
                'subgroup_id' => $subgroup->id
            ]);
        }

        // Get all dashboard permissions we just created
        $dashboardPermissions = Permission::where('name', 'Dashboard')->get();

        // Assign all dashboard permissions to role_id 1 (Admin)
        foreach ($dashboardPermissions as $permission) {
            RoleResponsibility::firstOrCreate([
                'role_id' => 1,
                'permission_id' => $permission->id
            ]);
        }

        $this->command->info('Dashboard permissions created and assigned to Admin role.');
    }
}